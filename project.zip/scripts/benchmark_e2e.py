"""End-to-end benchmark for the single Qwen3.5-4B visual pipeline."""

from __future__ import annotations

import argparse
import asyncio
import json
import platform
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from visual_service.model.lifecycle import load_qwen_runtime
from visual_service.model.pipeline import run_visual_pipeline
from visual_service.model.qwen_analyzer import analyze_window
from visual_service.settings import AnalysisMode, settings
from visual_service.video.profiles import semantic_profile


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--media",
        action="append",
        type=Path,
        help="Video path. Repeat for multiple videos. Defaults to data/test_videos/*.mp4.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "data" / "benchmark-qwen35-4b.json",
    )
    parser.add_argument(
        "--no-warmup",
        action="store_true",
        help="Do not run an unmeasured short vision warmup before the benchmark.",
    )
    parser.add_argument(
        "--mode",
        type=str,
        choices=[m.value for m in AnalysisMode],
        default=None,
        help="Analysis mode. Defaults to the configured setting.",
    )
    return parser.parse_args()


def video_duration_ms(path: Path) -> int:
    import av

    container = av.open(str(path))
    try:
        stream = container.streams.video[0]
        if stream.duration is not None:
            return int(float(stream.duration * stream.time_base) * 1000)
        if container.duration is not None:
            return int(container.duration / 1000)
    finally:
        container.close()
    raise RuntimeError(f"Could not determine duration for {path}")


async def run() -> None:
    args = parse_args()
    media_paths = args.media or sorted((PROJECT_ROOT / "data" / "test_videos").glob("*.mp4"))
    if not media_paths:
        raise SystemExit("No media files provided or found")
    for path in media_paths:
        if not path.is_file():
            raise SystemExit(f"Video does not exist: {path}")

    mode = AnalysisMode(args.mode) if args.mode else None

    runtime = await load_qwen_runtime(settings)
    try:
        warmup_record = None
        if not args.no_warmup:
            warmup_path = media_paths[0]
            warmup_duration = min(video_duration_ms(warmup_path), 3_000)
            warmup = await analyze_window(
                runtime,
                warmup_path,
                0,
                warmup_duration,
                semantic_profile(settings),
                settings,
            )
            warmup_record = {
                "media": str(warmup_path),
                "durationMs": warmup_duration,
                "inferenceMs": warmup.attempt.inference_ms,
                "peakVramBytes": warmup.attempt.peak_vram_bytes,
            }

        results = []
        for media_path in media_paths:
            duration_ms = video_duration_ms(media_path)
            result = await run_visual_pipeline(
                runtime, media_path, duration_ms, settings, analysis_mode=mode,
            )
            results.append({
                "media": str(media_path.resolve()),
                "durationMs": duration_ms,
                "metrics": result.metrics.model_dump(),
                "validationWarnings": result.warnings,
                "consolidationDiagnostics": result.consolidated.diagnostics,
                "finalResult": {
                    "schemaVersion": settings.qwen_schema_version,
                    "summary": result.consolidated.summary,
                    "observations": result.consolidated.observations,
                    "visibleTexts": result.consolidated.visible_texts,
                    "objects": result.consolidated.objects,
                    "topics": result.consolidated.topics,
                },
                "attempts": [asdict(attempt) for attempt in result.trace.attempts],
            })

        kd = runtime.kernel_diagnostics
        report = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "system": {
                "platform": platform.platform(),
                "python": platform.python_version(),
                "device": runtime.device_name,
                "torch": runtime.torch_version,
                "hip": runtime.hip_version,
                "transformers": runtime.transformers_version,
                "qwenVlUtils": runtime.toolkit_version,
                "videoBackend": runtime.video_backend,
            },
            "model": {
                "id": runtime.model_id,
                "revision": runtime.model_revision,
                "configuredDtype": runtime.configured_dtype,
                "actualDtypeDistribution": runtime.actual_dtype_distribution,
                "attentionImplementation": runtime.attention_implementation,
                "thinkingEnabled": runtime.thinking_enabled,
            },
            "contract": {
                "promptVersion": settings.qwen_prompt_version,
                "schemaVersion": settings.qwen_schema_version,
                "analysisMode": (mode or settings.analysis_mode).value,
            },
            "kernelDiagnostics": kd.to_dict(),
            "configuration": {
                "semanticWindowDurationMs": settings.semantic_window_duration_ms,
                "semanticWindowOverlapMs": settings.semantic_window_overlap_ms,
                "semanticFps": settings.semantic_fps,
                "semanticMaxFrames": settings.semantic_max_frames,
                "semanticMaxPixels": settings.semantic_max_pixels,
                "ocrFps": settings.ocr_fps,
                "ocrMaxFramesTotal": settings.ocr_max_frames_total,
                "ocrBatchSize": settings.ocr_batch_size,
                "ocrMaxPixels": settings.ocr_max_pixels,
                "globalOverviewMaxFrames": settings.global_overview_max_frames,
                "globalOverviewMaxPixels": settings.global_overview_max_pixels,
            },
            "warmup": warmup_record,
            "results": results,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Benchmark written to {args.output}")
    finally:
        await runtime.close()


if __name__ == "__main__":
    asyncio.run(run())
