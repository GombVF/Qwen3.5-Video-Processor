from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image

from visual_service.video.profiles import VideoAnalysisProfile

logger = logging.getLogger(__name__)


class VideoDecodeError(Exception):
    pass


@dataclass
class DecodedVideo:
    image_inputs: list[Any] | None
    video_inputs: list[Any]
    video_kwargs: dict[str, Any]
    selected_frames: int
    effective_fps: float
    width: int
    height: int
    backend: str
    decode_ms: int


@dataclass(frozen=True)
class OcrFrame:
    sequence: int
    timestamp_ms: int
    image: Image.Image


def build_video_content(
    media_path: Path,
    start_ms: int,
    end_ms: int,
    profile: VideoAnalysisProfile,
) -> dict[str, Any]:
    return {
        "type": "video",
        "video": str(media_path),
        "video_start": start_ms / 1000.0,
        "video_end": end_ms / 1000.0,
        "fps": profile.fps,
        "min_frames": profile.min_frames,
        "max_frames": profile.max_frames,
        "max_pixels": profile.max_pixels,
    }


def decode_video_window(
    media_path: Path,
    start_ms: int,
    end_ms: int,
    profile: VideoAnalysisProfile,
    patch_size: int = 16,
) -> DecodedVideo:
    from qwen_vl_utils import process_vision_info
    from qwen_vl_utils.vision_process import get_video_reader_backend

    content = build_video_content(media_path, start_ms, end_ms, profile)
    messages = [{"role": "user", "content": [content]}]
    started = time.perf_counter()
    try:
        try:
            image_inputs, raw_video_inputs, video_kwargs = process_vision_info(
                messages,
                image_patch_size=patch_size,
                return_video_kwargs=True,
                return_video_metadata=True,
            )
        except TypeError:
            # qwen-vl-utils 0.0.14 does not expose every newer keyword on all builds.
            image_inputs, raw_video_inputs, video_kwargs = process_vision_info(
                messages, return_video_kwargs=True, return_video_metadata=True,
            )
    except Exception as exc:
        raise VideoDecodeError(
            f"Failed to decode {media_path} [{start_ms}ms-{end_ms}ms]: {exc}"
        ) from exc
    decode_ms = int((time.perf_counter() - started) * 1000)

    if not raw_video_inputs:
        raise VideoDecodeError(
            f"No video frames decoded from {media_path} [{start_ms}ms-{end_ms}ms]"
        )

    first = raw_video_inputs[0]
    metadata: dict[str, Any] = {}
    if isinstance(first, tuple):
        tensor, metadata = first
    else:
        tensor = first

    selected_frames = int(tensor.shape[0])
    height = int(tensor.shape[-2])
    width = int(tensor.shape[-1])
    native_fps = float(metadata.get("fps", profile.fps))
    total_frames = float(metadata.get("total_num_frames", selected_frames))
    effective_fps = selected_frames / max(total_frames, 1.0) * native_fps
    video_kwargs = dict(video_kwargs or {})
    video_kwargs["fps"] = effective_fps
    backend = str(metadata.get("video_backend") or get_video_reader_backend())

    logger.info("video_window_decoded", extra={"data": {
        "path": str(media_path),
        "startMs": start_ms,
        "endMs": end_ms,
        "selectedFrames": selected_frames,
        "effectiveFps": effective_fps,
        "width": width,
        "height": height,
        "backend": backend,
        "decodeMs": decode_ms,
    }})
    return DecodedVideo(
        image_inputs=image_inputs,
        video_inputs=[tensor],
        video_kwargs=video_kwargs,
        selected_frames=selected_frames,
        effective_fps=effective_fps,
        width=width,
        height=height,
        backend=backend,
        decode_ms=decode_ms,
    )


def plan_ocr_timestamps(duration_ms: int, fps: float, max_frames: int) -> list[int]:
    if duration_ms <= 0 or fps <= 0 or max_frames <= 0:
        return []
    desired = max(1, math.ceil(duration_ms / 1000.0 * fps))
    count = min(desired, max_frames)
    step = duration_ms / count
    return [min(duration_ms - 1, max(0, int((index + 0.5) * step))) for index in range(count)]


def extract_ocr_frames(
    media_path: Path,
    *,
    duration_ms: int,
    fps: float,
    max_frames: int,
    max_pixels: int,
) -> tuple[list[OcrFrame], int]:
    import av

    targets = plan_ocr_timestamps(duration_ms, fps, max_frames)
    if not targets:
        return [], 0
    started = time.perf_counter()
    frames: list[OcrFrame] = []
    target_index = 0
    container = av.open(str(media_path))
    try:
        stream = container.streams.video[0]
        for frame in container.decode(video=0):
            if frame.pts is None:
                continue
            timestamp_ms = int(float(frame.pts * stream.time_base) * 1000)
            while target_index < len(targets) and timestamp_ms >= targets[target_index]:
                image = _resize_to_pixel_budget(frame.to_image(), max_pixels)
                frames.append(OcrFrame(target_index, targets[target_index], image))
                target_index += 1
            if target_index >= len(targets):
                break
    except Exception as exc:
        raise VideoDecodeError(f"Failed to extract OCR frames from {media_path}: {exc}") from exc
    finally:
        container.close()
    decode_ms = int((time.perf_counter() - started) * 1000)
    return frames, decode_ms


def _resize_to_pixel_budget(image: Image.Image, max_pixels: int) -> Image.Image:
    width, height = image.size
    if width * height <= max_pixels:
        return image
    scale = math.sqrt(max_pixels / (width * height))
    resized = (max(1, int(width * scale)), max(1, int(height * scale)))
    return image.resize(resized, Image.Resampling.LANCZOS)
