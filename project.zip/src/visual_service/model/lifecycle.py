from __future__ import annotations

import importlib.metadata
import json
import logging
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch

from visual_service.settings import PROMPT_VERSION, Settings

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class KernelDiagnostics:
    flash_linear_attention_available: bool = False
    flash_linear_attention_active: bool = False
    causal_conv1d_available: bool = False
    causal_conv1d_active: bool = False
    linear_attention_backend: str = "reference"
    full_attention_backend: str = "sdpa"
    fallback_reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "flashLinearAttentionAvailable": self.flash_linear_attention_available,
            "flashLinearAttentionActive": self.flash_linear_attention_active,
            "causalConv1dAvailable": self.causal_conv1d_available,
            "causalConv1dActive": self.causal_conv1d_active,
            "linearAttentionBackend": self.linear_attention_backend,
            "fullAttentionBackend": self.full_attention_backend,
            "fallbackReasons": list(self.fallback_reasons),
        }


@dataclass
class QwenRuntime:
    model: Any
    processor: Any
    device_name: str
    model_id: str
    model_revision: str
    prompt_version: str
    configured_dtype: str
    actual_dtype_distribution: dict[str, int]
    attention_implementation: str
    thinking_enabled: bool
    torch_version: str
    hip_version: str
    transformers_version: str
    toolkit_version: str
    video_backend: str
    loaded_at: datetime
    kernel_diagnostics: KernelDiagnostics = field(default_factory=KernelDiagnostics)
    _closed: bool = field(default=False, repr=False)

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        del self.model
        del self.processor
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("qwen35_runtime_closed")


async def load_qwen_runtime(config: Settings) -> QwenRuntime:
    try:
        from transformers import AutoModelForMultimodalLM, AutoProcessor
        import transformers
    except ImportError as exc:
        raise RuntimeError(
            "Qwen3.5 requires a recent Transformers build exposing "
            "AutoModelForMultimodalLM. Run scripts/setup-env.ps1."
        ) from exc

    if config.qwen_prompt_version != PROMPT_VERSION:
        raise ValueError(f"Only prompt {PROMPT_VERSION!r} is supported")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA/ROCm is unavailable; Qwen3.5-4B must load on the GPU")

    logger.info("qwen35_load_start", extra={"data": {
        "modelId": config.qwen_model_id,
        "dtype": config.qwen_dtype,
        "attentionImplementation": config.qwen_attn_implementation,
        "thinkingEnabled": config.qwen_enable_thinking,
    }})
    started = time.perf_counter()
    dtype = getattr(torch, config.qwen_dtype, None)
    if dtype is None:
        raise ValueError(f"Unknown torch dtype: {config.qwen_dtype!r}")

    processor = AutoProcessor.from_pretrained(
        config.qwen_model_id,
        local_files_only=config.qwen_local_files_only,
    )
    model = AutoModelForMultimodalLM.from_pretrained(
        config.qwen_model_id,
        dtype=dtype,
        device_map={"": "cuda:0"},
        attn_implementation=config.qwen_attn_implementation,
        low_cpu_mem_usage=True,
        local_files_only=config.qwen_local_files_only,
    ).eval()

    model_type = getattr(model.config, "model_type", "")
    if model_type != "qwen3_5":
        raise RuntimeError(
            f"Configured checkpoint is {model_type!r}, expected the Qwen3.5 architecture"
        )
    if hasattr(model.config, "use_cache"):
        model.config.use_cache = True

    devices = {parameter.device.type for parameter in model.parameters()}
    if devices != {"cuda"}:
        raise RuntimeError(f"Model was not loaded entirely on the ROCm GPU: {sorted(devices)}")

    actual_dtypes = dict(Counter(str(parameter.dtype) for parameter in model.parameters()))
    device_name = torch.cuda.get_device_name(0)
    hip_version = getattr(torch.version, "hip", None) or "N/A"
    toolkit_version = _package_version("qwen-vl-utils")
    video_backend = _video_backend()
    kernel_diag = _detect_kernel_diagnostics(model, config.qwen_attn_implementation)
    elapsed = time.perf_counter() - started
    allocated = torch.cuda.memory_allocated(0)

    logger.info("qwen35_load_complete", extra={"data": {
        "elapsedS": round(elapsed, 2),
        "allocatedVramBytes": allocated,
        "device": device_name,
        "parameterDtypes": actual_dtypes,
        "kernelDiagnostics": kernel_diag.to_dict(),
    }})

    return QwenRuntime(
        model=model,
        processor=processor,
        device_name=device_name,
        model_id=config.qwen_model_id,
        model_revision=_resolve_revision(config.qwen_model_id),
        prompt_version=config.qwen_prompt_version,
        configured_dtype=config.qwen_dtype,
        actual_dtype_distribution=actual_dtypes,
        attention_implementation=config.qwen_attn_implementation,
        thinking_enabled=config.qwen_enable_thinking,
        torch_version=torch.__version__,
        hip_version=hip_version,
        transformers_version=transformers.__version__,
        toolkit_version=toolkit_version,
        video_backend=video_backend,
        loaded_at=datetime.now(timezone.utc),
        kernel_diagnostics=kernel_diag,
    )


def _detect_kernel_diagnostics(model: Any, attn_impl: str) -> KernelDiagnostics:
    fallback_reasons: list[str] = []

    fla_available = False
    try:
        import fla  # noqa: F401
        from fla.ops.gated_delta_rule import chunk_gated_delta_rule  # noqa: F401
        fla_available = True
    except ImportError:
        fallback_reasons.append("flash-linear-attention package not installed")
    except Exception as exc:
        fallback_reasons.append(
            f"flash-linear-attention installed but ops not usable: {exc}"
        )

    conv1d_available = False
    try:
        import causal_conv1d  # noqa: F401
        conv1d_available = True
    except ImportError:
        fallback_reasons.append("causal_conv1d package not installed")

    fla_active = False
    conv1d_active = False
    linear_backend = "reference"

    if fla_available:
        fla_active = _check_fla_active(model)
        if fla_active:
            linear_backend = "fla"
        else:
            fallback_reasons.append(
                "flash-linear-attention installed but not active on model layers"
            )

    if conv1d_available:
        conv1d_active = _check_conv1d_active(model)
        if not conv1d_active:
            fallback_reasons.append(
                "causal_conv1d installed but not active on model layers"
            )

    return KernelDiagnostics(
        flash_linear_attention_available=fla_available,
        flash_linear_attention_active=fla_active,
        causal_conv1d_available=conv1d_available,
        causal_conv1d_active=conv1d_active,
        linear_attention_backend=linear_backend,
        full_attention_backend=attn_impl,
        fallback_reasons=fallback_reasons,
    )


def _check_fla_active(model: Any) -> bool:
    try:
        for module in model.modules():
            cls_name = type(module).__name__
            if "DeltaNet" in cls_name or "GatedDeltaNet" in cls_name:
                if hasattr(module, "use_fla") and module.use_fla:
                    return True
                module_source = type(module).__module__ or ""
                if "fla" in module_source:
                    return True
    except Exception:
        pass
    return False


def _check_conv1d_active(model: Any) -> bool:
    try:
        for module in model.modules():
            cls_name = type(module).__name__
            if "CausalConv1d" in cls_name:
                module_source = type(module).__module__ or ""
                if "causal_conv1d" in module_source:
                    return True
    except Exception:
        pass
    return False


def _package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def _video_backend() -> str:
    try:
        from qwen_vl_utils.vision_process import get_video_reader_backend
        return str(get_video_reader_backend())
    except Exception:
        return "pyav"


def _resolve_revision(model_id: str) -> str:
    model_path = Path(model_id)
    ref_path = model_path / "refs" / "main"
    if ref_path.is_file():
        return ref_path.read_text(encoding="utf-8").strip()
    config_path = model_path / "config.json"
    if config_path.is_file():
        config_data = json.loads(config_path.read_text(encoding="utf-8"))
        return str(config_data.get("_commit_hash", "local"))
    return "remote-or-local-unresolved"
