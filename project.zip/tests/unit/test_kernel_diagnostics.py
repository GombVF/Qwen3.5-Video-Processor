"""Tests for kernel diagnostics (performance track)."""

import pytest

from visual_service.model.lifecycle import KernelDiagnostics, _detect_kernel_diagnostics


class TestKernelDiagnostics:
    def test_default_diagnostics(self):
        kd = KernelDiagnostics()
        assert kd.flash_linear_attention_available is False
        assert kd.flash_linear_attention_active is False
        assert kd.causal_conv1d_available is False
        assert kd.causal_conv1d_active is False
        assert kd.linear_attention_backend == "reference"
        assert kd.full_attention_backend == "sdpa"
        assert kd.fallback_reasons == []

    def test_to_dict(self):
        kd = KernelDiagnostics(
            flash_linear_attention_available=True,
            fallback_reasons=["test reason"],
        )
        d = kd.to_dict()
        assert d["flashLinearAttentionAvailable"] is True
        assert d["flashLinearAttentionActive"] is False
        assert d["fallbackReasons"] == ["test reason"]
        assert d["linearAttentionBackend"] == "reference"
        assert d["fullAttentionBackend"] == "sdpa"

    def test_to_dict_keys(self):
        kd = KernelDiagnostics()
        d = kd.to_dict()
        expected_keys = {
            "flashLinearAttentionAvailable",
            "flashLinearAttentionActive",
            "causalConv1dAvailable",
            "causalConv1dActive",
            "linearAttentionBackend",
            "fullAttentionBackend",
            "fallbackReasons",
        }
        assert set(d.keys()) == expected_keys


class TestDetectKernelDiagnostics:
    def test_reference_fallback_without_optional_packages(self):
        class FakeModel:
            def modules(self):
                return []

        kd = _detect_kernel_diagnostics(FakeModel(), "sdpa")
        assert kd.flash_linear_attention_available is False
        assert kd.flash_linear_attention_active is False
        assert kd.causal_conv1d_available is False
        assert kd.causal_conv1d_active is False
        assert kd.linear_attention_backend == "reference"
        assert kd.full_attention_backend == "sdpa"
        assert any("flash-linear-attention" in r for r in kd.fallback_reasons)
        assert any("causal_conv1d" in r for r in kd.fallback_reasons)

    def test_full_attention_backend_reflects_config(self):
        class FakeModel:
            def modules(self):
                return []

        kd = _detect_kernel_diagnostics(FakeModel(), "eager")
        assert kd.full_attention_backend == "eager"

    def test_diagnostics_available_vs_active_distinction(self):
        kd = KernelDiagnostics(
            flash_linear_attention_available=True,
            flash_linear_attention_active=False,
        )
        assert kd.flash_linear_attention_available is True
        assert kd.flash_linear_attention_active is False
