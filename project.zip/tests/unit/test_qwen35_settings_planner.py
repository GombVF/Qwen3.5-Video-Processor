import pytest

from visual_service.settings import AnalysisMode, PROMPT_VERSION, SCHEMA_VERSION, Settings
from visual_service.video.decoder import plan_ocr_timestamps
from visual_service.video.planner import create_windows
from visual_service.video.profiles import semantic_profile


def test_single_version_defaults():
    config = Settings()
    assert config.qwen_prompt_version == PROMPT_VERSION
    assert config.qwen_schema_version == SCHEMA_VERSION
    assert config.qwen_model_id.endswith("Qwen3.5-4B")
    assert config.qwen_dtype == "bfloat16"
    assert config.qwen_enable_thinking is False
    assert config.qwen_max_concurrency == 1


def test_default_analysis_mode():
    config = Settings()
    assert config.analysis_mode == AnalysisMode.SEMANTIC_AND_OCR


def test_analysis_mode_semantic_only():
    config = Settings(analysis_mode="SEMANTIC_ONLY")
    assert config.analysis_mode == AnalysisMode.SEMANTIC_ONLY


def test_analysis_mode_semantic_and_ocr():
    config = Settings(analysis_mode="SEMANTIC_AND_OCR")
    assert config.analysis_mode == AnalysisMode.SEMANTIC_AND_OCR


def test_unsupported_analysis_mode_rejected():
    with pytest.raises(ValueError, match="Unsupported analysis mode"):
        Settings(analysis_mode="INVALID_MODE")


def test_unsupported_version_is_rejected():
    with pytest.raises(ValueError):
        Settings(qwen_prompt_version="visual-analysis-v5")


def test_thinking_cannot_be_enabled():
    with pytest.raises(ValueError):
        Settings(qwen_enable_thinking=True)


def test_windows_use_full_12_second_budget_with_overlap():
    windows, strategy = create_windows(27_000, semantic_profile(Settings()))
    assert strategy == "CHUNKED_NATIVE"
    assert [(w.start_ms, w.end_ms) for w in windows] == [
        (0, 12_000), (10_000, 22_000), (20_000, 27_000),
    ]


def test_ocr_plan_has_no_overlap_duplicates_and_respects_cap():
    timestamps = plan_ocr_timestamps(65_000, 1.0, 120)
    assert len(timestamps) == 65
    assert len(set(timestamps)) == 65
    capped = plan_ocr_timestamps(300_000, 1.0, 120)
    assert len(capped) == 120


def test_fragment_neighborhood_configurable():
    config = Settings()
    assert config.consolidation_fragment_neighborhood == 3
    config2 = Settings(consolidation_fragment_neighborhood=5)
    assert config2.consolidation_fragment_neighborhood == 5
